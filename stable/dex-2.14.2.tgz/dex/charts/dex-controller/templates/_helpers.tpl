{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "dex-controller.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "dex-controller.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "dex-controller.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Returns common labels.
*/}}
{{- define "dex-controller.labels.common" -}}
chart: {{ .Chart.Name }}-{{ .Chart.Version }}
release: {{ .Release.Name }}
heritage: {{ .Release.Service }}
{{- end -}}

{{/*
Returns labels for all services.
*/}}
{{- define "dex-controller.labels.service.common" -}}
{{- include "dex-controller.labels.common" . }}
{{- with .Values.service.common.labels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Returns labels for metric services.
*/}}
{{- define "dex-controller.labels.service.metrics" -}}
{{- include "dex-controller.labels.service.common" . }}
{{- with .Values.service.metrics.labels }}
{{ toYaml . }}
{{- end }}
{{- end -}}

{{/*
Returns labels for webhook services.
*/}}
{{- define "dex-controller.labels.service.webhook" -}}
{{- include "dex-controller.labels.service.common" . }}
{{- with .Values.service.webhook.labels }}
{{ toYaml . }}
{{- end }}
{{- end -}}
